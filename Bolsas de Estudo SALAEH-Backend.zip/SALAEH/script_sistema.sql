-- Script de criação do banco de dados
-- Sistema de Cadastro e Gestão de Bolsas

CREATE DATABASE IF NOT EXISTS sistema_bolsas;
USE sistema_bolsas;

-- Tabela de Cadastro (principal)
CREATE TABLE cadastro (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tipo_bolsa VARCHAR(100) NOT NULL,
    situacao_socioeconomica ENUM('Academico', 'Instituicional', 'Merito', 'Outros') NOT NULL,
    tipo_acao_solicitada VARCHAR(200) NOT NULL,
    duracao_pretendida_bolsa INT NOT NULL COMMENT 'Duração em anos',
    nome VARCHAR(100) NOT NULL,
    apelido VARCHAR(50),
    data_nascimento DATE NOT NULL,
    estado_civil ENUM('Solteiro', 'Casado', 'Divorciado', 'Viúvo') NOT NULL,
    nacionalidade VARCHAR(50) NOT NULL DEFAULT 'Mocambicana',
    naturalidade VARCHAR(100) NOT NULL,
    endereco TEXT NOT NULL,
    nivel_academico ENUM('Ensino Fundamental', 'Ensino Médio', 'Graduação', 'Pós-Graduação', 'Mestrado', 'Doutorado') NOT NULL,
    curso VARCHAR(100) NOT NULL,
    profissao VARCHAR(100),
    senha VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de Login
CREATE TABLE login (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(150) UNIQUE NOT NULL,
    senha VARCHAR(255) NOT NULL,
    cadastro_id INT,
    ultimo_acesso TIMESTAMP NULL,
    ativo BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (cadastro_id) REFERENCES cadastro(id) ON DELETE CASCADE
);

-- Tabela de Contato
CREATE TABLE contato (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL,
    mensagem TEXT NOT NULL,
    respondido BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela Sobre (para feedbacks)
CREATE TABLE sobre (
    id INT AUTO_INCREMENT PRIMARY KEY,
    feedback TEXT NOT NULL,
    usuario_id INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES cadastro(id) ON DELETE SET NULL
);
