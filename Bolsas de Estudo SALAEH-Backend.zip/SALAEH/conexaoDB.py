import pyodbc

def conectar():
    try:
        conn_str = (
            "DRIVER={ODBC Driver 17 for SQL Server};"
            "SERVER=localhost;"
            "DATABASE=sistema_bolsas;"
            "UID=albino;"        # seu usuário
            "PWD=1234" # sua senha
        )
        conn = pyodbc.connect(conn_str)
        return conn
    except Exception as e:
        print("Erro de conexão:", e)
        return None