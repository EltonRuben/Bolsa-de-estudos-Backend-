-- Script de cria��o do banco de dados
-- Sistema de Cadastro e Gest�o de Bolsas
USE sistema_bolsas;

-- Tabela de Cadastro (principal)
CREATE TABLE cadastro (
    id INT PRIMARY KEY IDENTITY,
    tipo_bolsa VARCHAR(100) NOT NULL,
    situacao_socioeconomica VARCHAR(50) NOT NULL,
    tipo_acao_solicitada VARCHAR(200) NOT NULL,
    duracao_pretendida_bolsa INT NOT NULL,
    nome VARCHAR(100) NOT NULL,
    apelido VARCHAR(50),
    data_nascimento DATE NOT NULL,
    estado_civil VARCHAR(20) NOT NULL,
    nacionalidade VARCHAR(50) NOT NULL DEFAULT 'Mocambicana',
    naturalidade VARCHAR(100) NOT NULL,
    endereco TEXT NOT NULL,
    nivel_academico VARCHAR(50) NOT NULL,
    curso VARCHAR(100) NOT NULL,
    profissao VARCHAR(100),
    senha VARCHAR(255) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de Login
CREATE TABLE login (
    id INT PRIMARY KEY NOT NULL IDENTITY,
    email VARCHAR(150) UNIQUE NOT NULL,
    senha VARCHAR(255) NOT NULL,
    cadastro_id INT,
    ultimo_acesso DATETIME NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    FOREIGN KEY (cadastro_id) REFERENCES cadastro(id) ON DELETE CASCADE
);

-- Tabela de Contato
CREATE TABLE contato (
    id INT PRIMARY KEY NOT NULL IDENTITY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL,
    mensagem TEXT NOT NULL,
    respondido INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Tabela Sobre (para feedbacks)
CREATE TABLE sobre (
    id INT PRIMARY KEY NOT NULL IDENTITY,
    feedback TEXT NOT NULL,
    usuario_id INT NULL,
    avaliacao INT CHECK (avaliacao >= 1 AND avaliacao <= 5),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES cadastro(id) ON DELETE SET NULL
);

SELECT name FROM sys.tables;
