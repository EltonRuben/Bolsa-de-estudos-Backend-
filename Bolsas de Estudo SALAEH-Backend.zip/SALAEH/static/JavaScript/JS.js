<script>
  // Elementos
  const themeToggle = document.createElement('button');
  themeToggle.className = 'theme-toggle';
  themeToggle.innerHTML = '🌓';
  document.body.appendChild(themeToggle);

  // Função para alternar dark mode
  function toggleDarkMode() {
    document.body.classList.toggle('dark-mode');
    
    // Salvar preferência
    const isDarkMode = document.body.classList.contains('dark-mode');
    localStorage.setItem('darkMode', isDarkMode);
    
    // Atualizar ícone
    themeToggle.innerHTML = isDarkMode ? '☀️' : '🌙';
  }

  // Verificar preferência salva
  if (localStorage.getItem('darkMode') === 'true') {
    document.body.classList.add('dark-mode');
    themeToggle.innerHTML = '☀️';
  }

  // Evento de clique
  themeToggle.addEventListener('click', toggleDarkMode);

  // Verificar preferência do sistema
  if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
    document.body.classList.add('dark-mode');
    themeToggle.innerHTML = '☀️';
  }
</script>