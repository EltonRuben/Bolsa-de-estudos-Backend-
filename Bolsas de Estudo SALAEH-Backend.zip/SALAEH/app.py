from flask import Flask, render_template, request, redirect, url_for
from conexaoDB import conectar

app = Flask(__name__)

#pagina incicial
@app.route('/')
def index():
    return render_template('index.html')

#pagina de login
@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/login-form', methods=['POST'])
def login_form():
    email = request.form['email']
    senha = request.form['senha']

    connLogin = conectar()
    cursor = connLogin.cursor()

    query = """
    INSERT INTO login(email, senha) 
    values(?,?)
    """
    cursor.execute(query, (email, senha))
    connLogin.commit()
    connLogin.close()
    return redirect(url_for('sucesso'))


#pagina de contato
@app.route('/contacto')
def contato():
    return render_template('contacto.html')

@app.route('/contacto-form', methods=['POST'])
def contato_form():
    nome = request.form['nome']
    email = request.form['email']
    mensagem = request.form['mensagem']
    conn = conectar()
    cursor = conn.cursor()
    query = """
    INSERT INTO contato (nome, email, mensagem)
    VALUES (?, ?, ?)
    """
    cursor.execute(query, (nome, email, mensagem))
    conn.commit()
    conn.close()
    return redirect(url_for('sucesso'))

#pagina de sobre
@app.route('/sobre')
def sobre():
    return render_template('sobre.html')

@app.route('/feedback-group', methods=['POST'])
def feedback_group():
    feedback = request.form['feedback']
    conn = conectar()
    cursor = conn.cursor()

    query = """
    INSERT INTO sobre (feedback)
    VALUES (?)
    """
    cursor.execute(query, (feedback))
    conn.commit()
    conn.close()
    return redirect(url_for('sucesso'))

#pagina de cadastro
@app.route('/cadastro')
def cadastro():
    return render_template('cadastro.html')

@app.route('/cadastro', methods=['POST'])
def cadastrar():
    nome = request.form['nome']
    apelido = request.form['apelido']
    senha = request.form['senha']
    tipo_bolsa = request.form['tipo_bolsa']
    situacao_socioeconomica = request.form['situacao_socioeconomica']   
    tipo_acao_solicitada = request.form['tipo_acao_solicitada'] 
    duracao_pretendida_bolsa = request.form['duracao_pretendida_bolsa']
    data_nascimento = request.form['data_nascimento']   
    estado_civil = request.form['estado_civil']
    nacionalidade = request.form['nacionalidade']   
    naturalidade = request.form['naturalidade'] 
    endereco = request.form['endereco'] 
    nivel_academico = request.form['nivel_academico']   
    curso = request.form ['curso']
    
    

    conn = conectar()
    cursor = conn.cursor()
    
    query = """
        INSERT INTO cadastro (nome, apelido, senha, tipo_bolsa, situacao_socioeconomica, 
        tipo_acao_solicitada, duracao_pretendida_bolsa, data_nascimento, estado_civil, 
        nacionalidade, naturalidade, endereco, nivel_academico, curso)
        VALUES (?, ?, ?, '?', '?', '?', ?, '?', '?', '?', '?', '?', '?')
    """

    cursor.execute(query, (nome, apelido, senha, tipo_bolsa, situacao_socioeconomica, tipo_acao_solicitada, duracao_pretendida_bolsa, data_nascimento, estado_civil, nacionalidade, naturalidade, endereco, nivel_academico, curso))
    conn.commit()
    conn.close()

    return redirect(url_for('sucesso'))

@app.route('/CadastrioSucedido')
def sucesso():
    return render_template('cadastroSucedido.html')



@app.route('/recuperarSenha')
def recuperarSenha():
    return render_template('recuperarSenha.html')

@app.route('/recuperarSenha', methods=['POST'])
def recuperarSenhaForm():
    email = request.form['email']
    conn = conectar()
    cursor = conn.cursor()

    query = """   
    INSERT INTO recuperadora(email)
    VALUES (?)
    """ 
    cursor.execute(query,(email))             
    conn.commit()
    conn.close()
    return redirect(url_for('sucesso'))                 

if __name__ == '__main__':
    app.run(debug=True)
